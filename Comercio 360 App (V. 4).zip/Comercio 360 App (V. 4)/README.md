
  # Comercio 360 App

  This is a code bundle for Comercio 360 App. The original project is available at https://www.figma.com/design/x2FrYGqBDQe1Pk58aqsMUN/Comercio-360-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  