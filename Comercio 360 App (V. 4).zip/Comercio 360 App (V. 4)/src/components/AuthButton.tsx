import React from "react";

interface Props {
  label: string;
  onClick?: () => void;
  type?: "button" | "submit";
  loading?: boolean;
}

const AuthButton: React.FC<Props> = ({ label, onClick, type = "button", loading }) => {
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={loading}
      className="w-full bg-purple-600 text-white py-3 rounded-xl text-lg font-semibold 
                 hover:bg-purple-700 transition-all shadow-md active:scale-95"
    >
      {loading ? "Cargando..." : label}
    </button>
  );
};

export default AuthButton;
