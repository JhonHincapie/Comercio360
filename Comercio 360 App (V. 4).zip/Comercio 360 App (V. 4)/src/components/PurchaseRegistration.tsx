import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Badge } from './ui/badge';
import { Alert, AlertDescription } from './ui/alert';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Textarea } from './ui/textarea';
import { InventoryItem, Purchase, Expense } from '../App';
import { Plus, Trash2, ShoppingBag, TrendingUp, DollarSign } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface PurchaseRegistrationProps {
  inventory: InventoryItem[];
  setInventory: (inventory: InventoryItem[]) => void;
  purchases: Purchase[];
  setPurchases: (purchases: Purchase[]) => void;
  expenses: Expense[];
  setExpenses: (expenses: Expense[]) => void;
}

interface PurchaseItem {
  itemId: string;
  name: string;
  quantity: number;
  cost: number;
}

export function PurchaseRegistration({ 
  inventory, 
  setInventory, 
  purchases, 
  setPurchases, 
  expenses, 
  setExpenses 
}: PurchaseRegistrationProps) {
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isExpenseDialogOpen, setIsExpenseDialogOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [expenseSearchTerm, setExpenseSearchTerm] = useState('');
  
  const [purchaseItems, setPurchaseItems] = useState<PurchaseItem[]>([]);
  const [supplier, setSupplier] = useState('');
  const [newSupplierName, setNewSupplierName] = useState('');
  const [invoiceNumber, setInvoiceNumber] = useState('');
  const [selectedProduct, setSelectedProduct] = useState('');
  const [quantity, setQuantity] = useState('');
  const [cost, setCost] = useState('');

  const [expenseDescription, setExpenseDescription] = useState('');
  const [expenseCategory, setExpenseCategory] = useState('');
  const [expenseAmount, setExpenseAmount] = useState('');
  const [expenseNotes, setExpenseNotes] = useState('');

  const resetForm = () => {
    setPurchaseItems([]);
    setSupplier('');
    setNewSupplierName('');
    setInvoiceNumber('');
    setSelectedProduct('');
    setQuantity('');
    setCost('');
  };

  const resetExpenseForm = () => {
    setExpenseDescription('');
    setExpenseCategory('');
    setExpenseAmount('');
    setExpenseNotes('');
  };

  const handleAddItemToForm = () => {
    if (!selectedProduct || !quantity || !cost) {
      toast.error('Completa todos los campos del producto');
      return;
    }

    const product = inventory.find(item => item.id === selectedProduct);
    if (!product) {
      toast.error('Producto no encontrado');
      return;
    }

    const existingItem = purchaseItems.find(item => item.itemId === selectedProduct);
    if (existingItem) {
      setPurchaseItems(purchaseItems.map(item =>
        item.itemId === selectedProduct
          ? { ...item, quantity: item.quantity + parseInt(quantity), cost: parseFloat(cost) }
          : item
      ));
    } else {
      setPurchaseItems([...purchaseItems, {
        itemId: product.id,
        name: product.name,
        quantity: parseInt(quantity),
        cost: parseFloat(cost)
      }]);
    }

    setSelectedProduct('');
    setQuantity('');
    setCost('');
    toast.success('Producto agregado a la compra');
  };

  const handleRemoveItemFromForm = (itemId: string) => {
    setPurchaseItems(purchaseItems.filter(item => item.itemId !== itemId));
  };

  const handleSubmitPurchase = (e: React.FormEvent) => {
    e.preventDefault();

    if (purchaseItems.length === 0) {
      toast.error('Agrega al menos un producto a la compra');
      return;
    }

    const finalSupplier = newSupplierName.trim() || supplier;
    if (!finalSupplier) {
      toast.error('Selecciona o ingresa el nombre del proveedor');
      return;
    }

    const updatedInventory = inventory.map(item => {
      const purchaseItem = purchaseItems.find(pi => pi.itemId === item.id);
      if (purchaseItem) {
        return {
          ...item,
          quantity: item.quantity + purchaseItem.quantity,
          cost: purchaseItem.cost,
          supplier: finalSupplier
        };
      }
      return item;
    });

    const total = purchaseItems.reduce((sum, item) => sum + (item.quantity * item.cost), 0);
    const newPurchase: Purchase = {
      id: Date.now().toString(),
      date: new Date().toISOString(),
      supplier: finalSupplier,
      items: purchaseItems,
      total,
      invoiceNumber: invoiceNumber || undefined
    };

    setInventory(updatedInventory);
    setPurchases([...purchases, newPurchase]);
    setIsAddDialogOpen(false);
    resetForm();
    
    toast.success('Compra registrada exitosamente', {
      description: `Total: ${formatCOP(total)} - ${purchaseItems.reduce((sum, item) => sum + item.quantity, 0)} unidades`
    });
  };

  const handleSubmitExpense = (e: React.FormEvent) => {
    e.preventDefault();

    if (!expenseDescription || !expenseCategory || !expenseAmount) {
      toast.error('Completa todos los campos obligatorios');
      return;
    }

    const newExpense: Expense = {
      id: Date.now().toString(),
      date: new Date().toISOString(),
      description: expenseDescription,
      category: expenseCategory,
      amount: parseFloat(expenseAmount),
      notes: expenseNotes || undefined
    };

    setExpenses([...expenses, newExpense]);
    setIsExpenseDialogOpen(false);
    resetExpenseForm();

    toast.success('Gasto registrado exitosamente', {
      description: `${expenseDescription} - ${formatCOP(parseFloat(expenseAmount))}`
    });
  };

  const handleDeleteExpense = (id: string) => {
    if (confirm('¿Estás seguro de eliminar este gasto?')) {
      setExpenses(expenses.filter(expense => expense.id !== id));
      toast.success('Gasto eliminado');
    }
  };

  const formatCOP = (value: number) => {
    return new Intl.NumberFormat('es-CO', {
      style: 'currency',
      currency: 'COP',
      minimumFractionDigits: 0,
    }).format(value);
  };

  const existingSuppliers = Array.from(new Set(
    inventory.map(item => item.supplier).filter(Boolean)
  )) as string[];

  const filteredPurchases = purchases.filter(purchase =>
    purchase.supplier.toLowerCase().includes(searchTerm.toLowerCase()) ||
    purchase.invoiceNumber?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    purchase.items.some(item => item.name.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const filteredExpenses = expenses.filter(expense =>
    expense.description.toLowerCase().includes(expenseSearchTerm.toLowerCase()) ||
    expense.category.toLowerCase().includes(expenseSearchTerm.toLowerCase()) ||
    expense.notes?.toLowerCase().includes(expenseSearchTerm.toLowerCase())
  );

  const totalPurchases = purchases.reduce((sum, purchase) => sum + purchase.total, 0);
  const totalExpenses = expenses.reduce((sum, expense) => sum + expense.amount, 0);
  
  const monthlyPurchases = purchases.filter(purchase => {
    const purchaseDate = new Date(purchase.date);
    const today = new Date();
    return purchaseDate.getMonth() === today.getMonth() &&
           purchaseDate.getFullYear() === today.getFullYear();
  });
  const monthlyTotal = monthlyPurchases.reduce((sum, purchase) => sum + purchase.total, 0);
  
  const monthlyExpenses = expenses.filter(expense => {
    const expenseDate = new Date(expense.date);
    const today = new Date();
    return expenseDate.getMonth() === today.getMonth() &&
           expenseDate.getFullYear() === today.getFullYear();
  });
  const monthlyExpensesTotal = monthlyExpenses.reduce((sum, expense) => sum + expense.amount, 0);

  const purchaseFormTotal = purchaseItems.reduce((sum, item) => sum + (item.quantity * item.cost), 0);

  const expenseCategories = [
    'Mantenimiento',
    'Reparaciones',
    'Remodelación',
    'Estantería',
    'Equipamiento',
    'Servicios',
    'Publicidad',
    'Transporte',
    'Otro'
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-gray-900">Registro de Compras y Gastos</h1>
          <p className="text-gray-500">Registra compras a proveedores, gastos del negocio y actualiza inventario</p>
        </div>
        <div className="flex space-x-2">
          <Dialog open={isExpenseDialogOpen} onOpenChange={setIsExpenseDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-orange-600 hover:bg-orange-700">
                <Plus className="w-4 h-4 mr-2" />
                Agregar Gasto
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Registrar Nuevo Gasto</DialogTitle>
                <DialogDescription>
                  Registra gastos operativos del negocio (reparaciones, mantenimiento, equipamiento, etc.)
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleSubmitExpense} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="expenseDescription">Descripción del Gasto *</Label>
                    <Input
                      id="expenseDescription"
                      placeholder="Ej: Reparación de nevera"
                      value={expenseDescription}
                      onChange={(e) => setExpenseDescription(e.target.value)}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="expenseCategory">Categoría *</Label>
                    <Select value={expenseCategory} onValueChange={setExpenseCategory} required>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecciona una categoría" />
                      </SelectTrigger>
                      <SelectContent>
                        {expenseCategories.map(category => (
                          <SelectItem key={category} value={category}>
                            {category}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="expenseAmount">Monto *</Label>
                  <Input
                    id="expenseAmount"
                    type="number"
                    min="0"
                    step="0.01"
                    placeholder="Ej: 150000"
                    value={expenseAmount}
                    onChange={(e) => setExpenseAmount(e.target.value)}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="expenseNotes">Notas (opcional)</Label>
                  <Textarea
                    id="expenseNotes"
                    placeholder="Detalles adicionales sobre el gasto..."
                    value={expenseNotes}
                    onChange={(e) => setExpenseNotes(e.target.value)}
                    rows={3}
                  />
                </div>

                <div className="flex justify-end space-x-2">
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => {
                      setIsExpenseDialogOpen(false);
                      resetExpenseForm();
                    }}
                  >
                    Cancelar
                  </Button>
                  <Button type="submit" className="bg-orange-600 hover:bg-orange-700">
                    <DollarSign className="w-4 h-4 mr-2" />
                    Registrar Gasto
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>

          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-blue-600 hover:bg-blue-700">
                <Plus className="w-4 h-4 mr-2" />
                Agregar Compra
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Registrar Nueva Compra</DialogTitle>
                <DialogDescription>
                  Completa la información de la compra al proveedor
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleSubmitPurchase} className="space-y-6">
                <div className="bg-blue-50 p-4 rounded-lg space-y-4">
                  <h3 className="text-gray-900">Información del Proveedor</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="supplier">Seleccionar Proveedor Existente</Label>
                      <Select value={supplier} onValueChange={setSupplier} disabled={!!newSupplierName}>
                        <SelectTrigger>
                          <SelectValue placeholder="Selecciona un proveedor" />
                        </SelectTrigger>
                        <SelectContent>
                          {existingSuppliers.map(sup => (
                            <SelectItem key={sup} value={sup}>
                              {sup}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="newSupplier">O Crear Nuevo Proveedor</Label>
                      <Input
                        id="newSupplier"
                        placeholder="Nombre del nuevo proveedor"
                        value={newSupplierName}
                        onChange={(e) => {
                          setNewSupplierName(e.target.value);
                          if (e.target.value) setSupplier('');
                        }}
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="invoiceNumber">Número de Factura (opcional)</Label>
                    <Input
                      id="invoiceNumber"
                      placeholder="Ej: FC-001234"
                      value={invoiceNumber}
                      onChange={(e) => setInvoiceNumber(e.target.value)}
                    />
                  </div>
                </div>

                <div className="border rounded-lg p-4 space-y-4">
                  <h3 className="text-gray-900">Agregar Productos a la Compra</h3>
                  <div className="grid grid-cols-12 gap-4">
                    <div className="col-span-5 space-y-2">
                      <Label htmlFor="product">Producto *</Label>
                      <Select 
                        value={selectedProduct} 
                        onValueChange={(value) => {
                          setSelectedProduct(value);
                          const product = inventory.find(item => item.id === value);
                          if (product) {
                            setCost(product.cost.toString());
                          }
                        }}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Selecciona un producto" />
                        </SelectTrigger>
                        <SelectContent>
                          {inventory.map(item => (
                            <SelectItem key={item.id} value={item.id}>
                              {item.name} (Stock actual: {item.quantity})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="col-span-2 space-y-2">
                      <Label htmlFor="quantity">Cantidad *</Label>
                      <Input
                        id="quantity"
                        type="number"
                        min="1"
                        placeholder="Ej: 10"
                        value={quantity}
                        onChange={(e) => setQuantity(e.target.value)}
                      />
                    </div>
                    <div className="col-span-4 space-y-2">
                      <Label htmlFor="cost">Costo Unitario *</Label>
                      <Input
                        id="cost"
                        type="number"
                        min="0"
                        step="0.01"
                        placeholder="Ej: 25000"
                        value={cost}
                        onChange={(e) => setCost(e.target.value)}
                        className="w-full"
                      />
                    </div>
                    <div className="col-span-1 space-y-2">
                      <Label className="invisible">Agregar</Label>
                      <Button 
                        type="button" 
                        onClick={handleAddItemToForm} 
                        className="bg-green-600 hover:bg-green-700 w-full"
                      >
                        <Plus className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>

                  {purchaseItems.length > 0 && (
                    <div className="border-t pt-4">
                      <h4 className="mb-2 text-gray-700">Productos en esta compra:</h4>
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Producto</TableHead>
                              <TableHead>Cantidad</TableHead>
                              <TableHead>Costo Unit.</TableHead>
                              <TableHead>Subtotal</TableHead>
                              <TableHead></TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {purchaseItems.map((item) => (
                              <TableRow key={item.itemId}>
                                <TableCell>{item.name}</TableCell>
                                <TableCell>{item.quantity}</TableCell>
                                <TableCell>{formatCOP(item.cost)}</TableCell>
                                <TableCell>{formatCOP(item.quantity * item.cost)}</TableCell>
                                <TableCell>
                                  <Button
                                    type="button"
                                    size="sm"
                                    variant="destructive"
                                    onClick={() => handleRemoveItemFromForm(item.itemId)}
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </Button>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                      <div className="mt-4 flex justify-end space-x-8 border-t pt-4">
                        <div className="text-right">
                          <p className="text-sm text-gray-600">Total Unidades:</p>
                          <p className="text-gray-900">
                            {purchaseItems.reduce((sum, item) => sum + item.quantity, 0)}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="text-sm text-gray-600">Total Compra:</p>
                          <p className="text-gray-900">{formatCOP(purchaseFormTotal)}</p>
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                <div className="flex justify-end space-x-2">
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => {
                      setIsAddDialogOpen(false);
                      resetForm();
                    }}
                  >
                    Cancelar
                  </Button>
                  <Button 
                    type="submit" 
                    className="bg-blue-600 hover:bg-blue-700"
                    disabled={purchaseItems.length === 0}
                  >
                    <ShoppingBag className="w-4 h-4 mr-2" />
                    Registrar Compra
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Total Compras</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-gray-900">{formatCOP(totalPurchases)}</div>
            <div className="flex items-center mt-1 text-gray-600">
              <ShoppingBag className="w-4 h-4 mr-1" />
              <span className="text-sm">{purchases.length} transacciones</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Total Gastos</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-gray-900">{formatCOP(totalExpenses)}</div>
            <div className="flex items-center mt-1 text-orange-600">
              <DollarSign className="w-4 h-4 mr-1" />
              <span className="text-sm">{expenses.length} registros</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Compras del Mes</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-gray-900">{formatCOP(monthlyTotal)}</div>
            <div className="flex items-center mt-1 text-blue-600">
              <TrendingUp className="w-4 h-4 mr-1" />
              <span className="text-sm">{monthlyPurchases.length} transacciones</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Gastos del Mes</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-gray-900">{formatCOP(monthlyExpensesTotal)}</div>
            <div className="flex items-center mt-1 text-orange-600">
              <DollarSign className="w-4 h-4 mr-1" />
              <span className="text-sm">{monthlyExpenses.length} gastos</span>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Historial de Compras</CardTitle>
          <CardDescription>
            <Input
              placeholder="Buscar por proveedor, factura o producto..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="mt-2"
            />
          </CardDescription>
        </CardHeader>
        <CardContent>
          {filteredPurchases.length === 0 ? (
            <Alert>
              <AlertDescription>
                {purchases.length === 0 
                  ? 'No hay compras registradas. Agrega tu primera compra usando el botón "Agregar Compra".'
                  : 'No se encontraron compras con los criterios de búsqueda.'
                }
              </AlertDescription>
            </Alert>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Fecha</TableHead>
                    <TableHead>Proveedor</TableHead>
                    <TableHead>Factura</TableHead>
                    <TableHead>Productos</TableHead>
                    <TableHead>Unidades</TableHead>
                    <TableHead>Total</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredPurchases.slice().reverse().map((purchase) => (
                    <TableRow key={purchase.id}>
                      <TableCell>
                        <div>
                          <p>
                            {new Date(purchase.date).toLocaleDateString('es-CO', {
                              year: 'numeric',
                              month: 'short',
                              day: 'numeric'
                            })}
                          </p>
                          <p className="text-xs text-gray-500">
                            {new Date(purchase.date).toLocaleTimeString('es-CO', {
                              hour: '2-digit',
                              minute: '2-digit'
                            })}
                          </p>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className="border-blue-600 text-blue-800">
                          {purchase.supplier}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {purchase.invoiceNumber ? (
                          <Badge variant="secondary">
                            {purchase.invoiceNumber}
                          </Badge>
                        ) : (
                          <span className="text-gray-400 text-sm">Sin factura</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="text-sm">
                          {purchase.items.map((item, index) => (
                            <div key={`${item.itemId}-${index}`} className="text-gray-700">
                              {item.name}
                            </div>
                          ))}
                        </div>
                      </TableCell>
                      <TableCell>
                        {purchase.items.reduce((sum, item) => sum + item.quantity, 0)} unidades
                      </TableCell>
                      <TableCell>
                        <span>{formatCOP(purchase.total)}</span>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Historial de Gastos</CardTitle>
          <CardDescription>
            <Input
              placeholder="Buscar por descripción, categoría o notas..."
              value={expenseSearchTerm}
              onChange={(e) => setExpenseSearchTerm(e.target.value)}
              className="mt-2"
            />
          </CardDescription>
        </CardHeader>
        <CardContent>
          {filteredExpenses.length === 0 ? (
            <Alert>
              <AlertDescription>
                {expenses.length === 0 
                  ? 'No hay gastos registrados. Agrega tu primer gasto usando el botón "Agregar Gasto".'
                  : 'No se encontraron gastos con los criterios de búsqueda.'
                }
              </AlertDescription>
            </Alert>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Fecha</TableHead>
                    <TableHead>Descripción</TableHead>
                    <TableHead>Categoría</TableHead>
                    <TableHead>Monto</TableHead>
                    <TableHead>Notas</TableHead>
                    <TableHead>Acciones</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredExpenses.slice().reverse().map((expense) => (
                    <TableRow key={expense.id}>
                      <TableCell>
                        <div>
                          <p>
                            {new Date(expense.date).toLocaleDateString('es-CO', {
                              year: 'numeric',
                              month: 'short',
                              day: 'numeric'
                            })}
                          </p>
                          <p className="text-xs text-gray-500">
                            {new Date(expense.date).toLocaleTimeString('es-CO', {
                              hour: '2-digit',
                              minute: '2-digit'
                            })}
                          </p>
                        </div>
                      </TableCell>
                      <TableCell>{expense.description}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className="border-orange-600 text-orange-800">
                          {expense.category}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <span className="text-orange-700">{formatCOP(expense.amount)}</span>
                      </TableCell>
                      <TableCell>
                        {expense.notes ? (
                          <span className="text-sm text-gray-600">{expense.notes}</span>
                        ) : (
                          <span className="text-gray-400 text-sm">-</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => handleDeleteExpense(expense.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
