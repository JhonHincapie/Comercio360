import { logout } from "@/services/firebase";
import { useNavigate } from "react-router-dom";
import {
  LayoutDashboard,
  Boxes,
  ShoppingBag,
  Receipt,
  LogOut,
} from "lucide-react";

export default function Sidebar() {
  const navigate = useNavigate();

  const handleLogout = async () => {
    try {
      await logout();
      navigate("/", { replace: true }); // redirige al login
    } catch (error) {
      console.error("Error al cerrar sesión:", error);
    }
  };

  return (
    <div className="h-full bg-white shadow-lg p-5 flex flex-col justify-between">

      {/* Sección superior */}
      <div>
        <h2 className="text-xl font-bold mb-6">Comercio 360</h2>

        <ul className="space-y-3">
          <li onClick={() => navigate("/dashboard")} className="cursor-pointer flex items-center gap-3 hover:bg-gray-100 p-2 rounded-lg">
            <LayoutDashboard size={20} /> Dashboard
          </li>

          <li onClick={() => navigate("/inventario")} className="cursor-pointer flex items-center gap-3 hover:bg-gray-100 p-2 rounded-lg">
            <Boxes size={20} /> Inventario
          </li>

          <li onClick={() => navigate("/ventas")} className="cursor-pointer flex items-center gap-3 hover:bg-gray-100 p-2 rounded-lg">
            <Receipt size={20} /> Ventas
          </li>

          <li onClick={() => navigate("/compras")} className="cursor-pointer flex items-center gap-3 hover:bg-gray-100 p-2 rounded-lg">
            <ShoppingBag size={20} /> Compras / Gastos
          </li>
        </ul>
      </div>

      {/* Sección inferior: Cerrar sesión */}
      <button
        onClick={handleLogout}
        className="flex items-center gap-3 text-red-600 font-semibold hover:bg-red-50 p-2 rounded-lg"
      >
        <LogOut size={20} /> Cerrar sesión
      </button>
    </div>
  );
}
