export function StoreLogoWithFlag({ className = "w-6 h-6" }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      <defs>
        <linearGradient id="colombiaFlag" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" style={{ stopColor: '#FCD116', stopOpacity: 1 }} />
          <stop offset="50%" style={{ stopColor: '#FCD116', stopOpacity: 1 }} />
          <stop offset="50%" style={{ stopColor: '#003893', stopOpacity: 1 }} />
          <stop offset="75%" style={{ stopColor: '#003893', stopOpacity: 1 }} />
          <stop offset="75%" style={{ stopColor: '#CE1126', stopOpacity: 1 }} />
          <stop offset="100%" style={{ stopColor: '#CE1126', stopOpacity: 1 }} />
        </linearGradient>
      </defs>
      
      {/* Techo con bandera de Colombia */}
      <path
        d="M3 9L12 2L21 9"
        fill="url(#colombiaFlag)"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      
      {/* Cuerpo de la tienda */}
      <path
        d="M21 9V20C21 20.5304 20.7893 21.0391 20.4142 21.4142C20.0391 21.7893 19.5304 22 19 22H5C4.46957 22 3.96086 21.7893 3.58579 21.4142C3.21071 21.0391 3 20.5304 3 20V9"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      
      {/* Puerta */}
      <path
        d="M9 22V12H15V22"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}
