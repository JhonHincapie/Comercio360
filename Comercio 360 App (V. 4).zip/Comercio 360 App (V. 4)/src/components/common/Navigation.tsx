import { Button } from '../ui/button';
import { LayoutDashboard, Package, ShoppingCart, ShoppingBag, LogOut } from 'lucide-react';
import { StoreLogoWithFlag } from '../StoreLogoWithFlag';

interface NavigationProps {
  currentView: string;
  onViewChange: (view: string) => void;
  onLogout: () => void;
}

export function Navigation({ currentView, onViewChange, onLogout }: NavigationProps) {
  const navItems = [
    { id: 'dashboard', label: 'Panel Principal', icon: LayoutDashboard },
    { id: 'inventory', label: 'Inventario', icon: Package },
    { id: 'sales', label: 'Ventas', icon: ShoppingCart },
    { id: 'purchases', label: 'Compras', icon: ShoppingBag },
  ];

  return (
    <nav className="bg-white border-b border-gray-200 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-2">
            <div className="bg-blue-600 p-2 rounded-lg">
              <StoreLogoWithFlag className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl text-gray-900">Comercio 360</span>
          </div>

          <div className="hidden md:flex space-x-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              return (
                <Button
                  key={item.id}
                  variant={currentView === item.id ? 'default' : 'ghost'}
                  onClick={() => onViewChange(item.id)}
                  className={currentView === item.id ? 'bg-blue-600 hover:bg-blue-700' : ''}
                >
                  <Icon className="w-4 h-4 mr-2" />
                  {item.label}
                </Button>
              );
            })}
          </div>

          <Button variant="ghost" onClick={onLogout}>
            <LogOut className="w-4 h-4 mr-2" />
            Salir
          </Button>
        </div>

        {/* Mobile navigation */}
        <div className="md:hidden pb-3 flex overflow-x-auto space-x-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            return (
              <Button
                key={item.id}
                variant={currentView === item.id ? 'default' : 'ghost'}
                onClick={() => onViewChange(item.id)}
                className={`whitespace-nowrap ${currentView === item.id ? 'bg-blue-600 hover:bg-blue-700' : ''}`}
                size="sm"
              >
                <Icon className="w-4 h-4 mr-2" />
                {item.label}
              </Button>
            );
          })}
        </div>
      </div>
    </nav>
  );
}
