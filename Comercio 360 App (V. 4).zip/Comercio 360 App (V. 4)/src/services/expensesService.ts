import { collection, addDoc, getDocs, deleteDoc, doc } from "firebase/firestore";
import { db } from "./firebase";

const EXPENSES_COLLECTION = "expenses";

/** obtener gastos/compras */
export async function getExpenses() {
  const snapshot = await getDocs(collection(db, EXPENSES_COLLECTION));
  return snapshot.docs.map((d) => ({ id: d.id, ...d.data() }));
}

/** agregar gasto/compra */
export async function addExpense(data: {
  type: string; // compra - gasto
  description: string;
  amount: number;
  date: string;
}) {
  await addDoc(collection(db, EXPENSES_COLLECTION), data);
}

/** eliminar gasto/compra */
export async function deleteExpense(id: string) {
  await deleteDoc(doc(db, EXPENSES_COLLECTION, id));
}
