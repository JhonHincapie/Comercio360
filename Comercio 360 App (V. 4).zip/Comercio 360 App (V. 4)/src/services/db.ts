import { db } from "./firebase";
import {
  collection,
  addDoc,
  getDocs,
  getDoc,
  doc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy
} from "firebase/firestore";

export async function createItem(collectionName: string, data: any) {
  try {
    const docRef = await addDoc(collection(db, collectionName), data);
    return docRef.id;
  } catch (error) {
    console.error("Error creando documento:", error);
    return null;
  }
}

export async function getItems(collectionName: string) {
  try {
    const snapshot = await getDocs(collection(db, collectionName));
    return snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
  } catch (error) {
    console.error("Error obteniendo documentos:", error);
    return [];
  }
}

export async function updateItem(collectionName: string, id: string, data: any) {
  try {
    const ref = doc(db, collectionName, id);
    await updateDoc(ref, data);
    return true;
  } catch (error) {
    console.error("Error actualizando documento:", error);
    return false;
  }
}

export async function deleteItem(collectionName: string, id: string) {
  try {
    await deleteDoc(doc(db, collectionName, id));
    return true;
  } catch (error) {
    console.error("Error eliminando documento:", error);
    return false;
  }
}
