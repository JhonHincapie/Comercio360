// src/services/firebase.ts
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import { getFirestore } from "firebase/firestore";
import { signOut } from "firebase/auth";
import {
  getAuth,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  User,
} from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyBNTLFYe3X3Mv_OI2GyoBe9BnetSgRdUA0",
  authDomain: "comercio-360.firebaseapp.com",
  projectId: "comercio-360",
  storageBucket: "comercio-360.firebasestorage.app",
  messagingSenderId: "466955717012",
  appId: "1:466955717012:web:3e2e49e494d94f74862781",
  measurementId: "G-TQKD3Q7NSX"
};

// Inicializa Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

/**
 * Crea usuario con email y password
 */
export const registerWithEmail = async (email: string, password: string) => {
  const res = await createUserWithEmailAndPassword(auth, email, password);
  return res.user;
};

/**
 * Login con email y password
 */
export const loginWithEmail = async (email: string, password: string) => {
  const res = await signInWithEmailAndPassword(auth, email, password);
  return res.user;
};

/**
 * Logout
 */
export const logout = async () => {
  await signOut(auth);
};

/**
 * Observer (útil para mantener sesión)
 */
export const onAuthState = (cb: (user: User | null) => void) => {
  return onAuthStateChanged(auth, cb);
};

export { auth };
export const db = getFirestore(app);

