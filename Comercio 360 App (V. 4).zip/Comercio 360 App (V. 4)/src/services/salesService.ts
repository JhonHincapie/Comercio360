import { collection, addDoc, getDocs, deleteDoc, doc } from "firebase/firestore";
import { db } from "./firebase";

const SALES_COLLECTION = "sales";

/** obtener ventas */
export async function getSales() {
  const querySnapshot = await getDocs(collection(db, SALES_COLLECTION));
  return querySnapshot.docs.map((d) => ({
    id: d.id,
    ...d.data(),
  }));
}

/** agregar venta */
export async function addSale(data: {
  product: string;
  quantity: number;
  total: number;
  date: string;
}) {
  await addDoc(collection(db, SALES_COLLECTION), data);
}

/** eliminar venta */
export async function deleteSale(id: string) {
  await deleteDoc(doc(db, SALES_COLLECTION, id));
}
