import { collection, addDoc, getDocs, deleteDoc, doc } from "firebase/firestore";
import { db } from "./firebase";

const INVENTORY_COLLECTION = "inventory";

/** Obtener productos */
export async function getInventory() {
  const querySnapshot = await getDocs(collection(db, INVENTORY_COLLECTION));
  return querySnapshot.docs.map((docItem) => ({
    id: docItem.id,
    ...docItem.data(),
  }));
}

/** Agregar producto */
export async function addInventoryItem(item: {
  name: string;
  quantity: number;
  price: number;
}) {
  await addDoc(collection(db, INVENTORY_COLLECTION), item);
}

/** Eliminar producto */
export async function deleteInventoryItem(id: string) {
  await deleteDoc(doc(db, INVENTORY_COLLECTION, id));
}
