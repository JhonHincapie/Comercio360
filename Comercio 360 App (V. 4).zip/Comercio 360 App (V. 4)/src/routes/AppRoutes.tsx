import { BrowserRouter, Routes, Route } from "react-router-dom";
import LoginRegister from "@/pages/LoginRegister/LoginRegister";
import Dashboard from "@/pages/Dashboard/Dashboard";
import Inventory from "@/pages/Inventory/Inventory";
import Sales from "@/pages/Sales/Sales";
import Purchases from "@/pages/Purchases/Purchases";
import ProtectedRoute from "./ProtectedRoute";

export default function AppRoutes() {
  return (
    <BrowserRouter>
      <Routes>

        {/* RUTAS PÚBLICAS */}
        <Route path="/" element={<LoginRegister />} />

        {/* RUTAS PRIVADAS */}
        <Route
          path="/dashboard"
          element={
            <ProtectedRoute>
              <Dashboard />
            </ProtectedRoute>
          }
        />

        <Route
          path="/inventario"
          element={
            <ProtectedRoute>
              <Inventory />
            </ProtectedRoute>
          }
        />

        <Route
          path="/ventas"
          element={
            <ProtectedRoute>
              <Sales />
            </ProtectedRoute>
          }
        />

        <Route
          path="/compras"
          element={
            <ProtectedRoute>
              <Purchases />
            </ProtectedRoute>
          }
        />

      </Routes>
    </BrowserRouter>
  );
}
