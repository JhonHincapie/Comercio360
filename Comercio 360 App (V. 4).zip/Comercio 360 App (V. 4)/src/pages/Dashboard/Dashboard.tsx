import { motion } from "framer-motion";
import { useSales } from "@/hooks/useSales";
import { useExpenses } from "@/hooks/useExpenses";
import { useInventory } from "@/hooks/useInventory";

import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";

export default function Dashboard() {
  const { sales } = useSales();
  const { expenses } = useExpenses();
  const { inventory } = useInventory();

  // ---- Totales ----
  const totalVentas = sales.reduce((acc, s) => acc + s.amount, 0);
  const totalCompras = expenses
    .filter((e) => e.type === "compra")
    .reduce((acc, e) => acc + e.amount, 0);
  const totalGastos = expenses
    .filter((e) => e.type === "gasto")
    .reduce((acc, e) => acc + e.amount, 0);
  const totalInventario = inventory.reduce((acc, i) => acc + i.stock, 0);

  // ---- Gráfica de Ventas ----
  const salesChartData = sales.map((s) => ({
    date: new Date(s.date).toLocaleDateString(),
    value: s.amount,
  }));

  // ---- Gráfica de Gastos/Compras ----
  const expensesChartData = expenses.map((e) => ({
    date: new Date(e.date).toLocaleDateString(),
    value: e.amount,
  }));

  return (
    <div className="p-6 space-y-8">
      <h1 className="text-3xl font-bold">Dashboard</h1>

      {/* ---- Resumen ---- */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <Card>
            <CardHeader>
              <CardTitle>Total Ventas</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold text-green-600">${totalVentas}</p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <Card>
            <CardHeader>
              <CardTitle>Total Compras</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold text-blue-600">${totalCompras}</p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <Card>
            <CardHeader>
              <CardTitle>Total Gastos</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold text-red-600">${totalGastos}</p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <Card>
            <CardHeader>
              <CardTitle>Productos en Inventario</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold text-purple-600">{totalInventario}</p>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* ---- Gráficas ---- */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Ventas */}
        <Card>
          <CardHeader>
            <CardTitle>Ventas recientes</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="w-full h-64">
              <ResponsiveContainer>
                <LineChart data={salesChartData}>
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Line type="monotone" dataKey="value" stroke="#22c55e" strokeWidth={3} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Gastos y Compras */}
        <Card>
          <CardHeader>
            <CardTitle>Compras y Gastos</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="w-full h-64">
              <ResponsiveContainer>
                <BarChart data={expensesChartData}>
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="value" fill="#3b82f6" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* ---- Últimos movimientos ---- */}
      <Card>
        <CardHeader>
          <CardTitle>Últimos movimientos</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {[...sales.slice(-3), ...expenses.slice(-3)]
              .sort((a: any, b: any) => new Date(b.date).getTime() - new Date(a.date).getTime())
              .map((mov, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="p-3 border rounded-lg bg-gray-50 flex justify-between"
                >
                  <span>{mov.description || "Venta"}</span>
                  <span className="font-bold">${mov.amount}</span>
                </motion.div>
              ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
