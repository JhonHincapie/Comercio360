import React from "react";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import { loginWithEmail } from "@/services/firebase";
import { useNavigate, Link } from "react-router-dom";
import { motion } from "framer-motion";

type FormValues = {
  email: string;
  password: string;
};

const schema = yup.object({
  email: yup.string().email("Email inválido").required("Email es requerido"),
  password: yup
    .string()
    .required("Contraseña requerida")
    .min(6, "Mínimo 6 caracteres")
    .matches(/[A-Z]/, "Debe tener al menos una mayúscula")
    .matches(/[0-9]/, "Debe tener al menos un número")
    .matches(/[@$!%*?&]/, "Debe tener al menos un símbolo"),
}).required();

const Login: React.FC = () => {
  const navigate = useNavigate();
  const { register, handleSubmit, formState } = useForm<FormValues>({
    resolver: yupResolver(schema),
    mode: "onTouched",
  });

  const onSubmit = async (data: FormValues) => {
    try {
      await loginWithEmail(data.email, data.password);
      // redirige al dashboard
      navigate("/dashboard");
    } catch (err: any) {
      // Mapeo de errores comunes de Firebase
      const message =
        (err?.code && firebaseErrorMessage(err.code)) ||
        "Error al iniciar sesión";
      alert(message);
    }
  };

  return (
    <div style={styles.container}>
      <motion.div
        initial={{ opacity: 0, y: 20, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.45, type: "spring" }}
        style={styles.card}
      >
        <h2 style={styles.title}>Comercio 360</h2>
        <p style={styles.subtitle}>Bienvenido — inicia sesión</p>

        <form onSubmit={handleSubmit(onSubmit)} style={styles.form}>
          <label style={styles.label}>Correo</label>
          <input {...register("email")} style={styles.input} placeholder="ejemplo@correo.com" />
          {formState.errors.email && <span style={styles.err}>{formState.errors.email.message}</span>}

          <label style={styles.label}>Contraseña</label>
          <input {...register("password")} type="password" style={styles.input} placeholder="••••••••" />
          {formState.errors.password && <span style={styles.err}>{formState.errors.password.message}</span>}

          <button type="submit" style={styles.button}>Iniciar sesión</button>
        </form>

        <div style={styles.footer}>
          <span>¿No tienes cuenta?</span>{" "}
          <Link to="/registro" style={styles.link}>Crear cuenta</Link>
        </div>
      </motion.div>
    </div>
  );
};

export default Login;

/* Estilos inline (puedes llevarlos a CSS/Tailwind luego) */
const styles: Record<string, React.CSSProperties> = {
  container: {
    height: "100vh",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    background: "linear-gradient(180deg,#f7fbff,#f1f6ff)",
    padding: "20px",
  },
  card: {
    width: 420,
    borderRadius: 14,
    padding: 28,
    boxShadow: "0 8px 30px rgba(17,24,39,0.08)",
    background: "white",
  },
  title: { fontSize: 22, fontWeight: 700, marginBottom: 4 },
  subtitle: { fontSize: 13, color: "#67748a", marginBottom: 18 },
  form: { display: "flex", flexDirection: "column" },
  label: { fontSize: 13, marginBottom: 6 },
  input: {
    padding: "12px 14px",
    borderRadius: 10,
    border: "1px solid #e6eef8",
    marginBottom: 10,
    fontSize: 14,
    outline: "none",
  },
  button: {
    marginTop: 6,
    padding: "12px 14px",
    borderRadius: 10,
    border: "none",
    background: "linear-gradient(90deg,#6c5ce7,#00b894)",
    color: "white",
    fontWeight: 700,
    cursor: "pointer",
  },
  footer: { marginTop: 14, textAlign: "center", color: "#475569" },
  link: { color: "#2b6cb0", fontWeight: 600, textDecoration: "none" },
  err: { color: "#d9534f", fontSize: 12, marginBottom: 6 },
};

/* Helper error mapping */
function firebaseErrorMessage(code: string) {
  switch (code) {
    case "auth/wrong-password":
      return "Contraseña incorrecta";
    case "auth/user-not-found":
      return "Usuario no encontrado";
    case "auth/too-many-requests":
      return "Demasiados intentos. Intenta más tarde.";
    default:
      return "Error de autenticación";
  }
}
