import { useState } from "react";
import { useInventory } from "@/hooks/useInventory";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Trash2 } from "lucide-react";

export default function Inventory() {
  const { items, loading, addItem, removeItem } = useInventory();

  const [form, setForm] = useState({
    name: "",
    quantity: "",
    price: "",
  });

  function handleChange(e: any) {
    setForm({ ...form, [e.target.name]: e.target.value });
  }

  async function handleSubmit(e: any) {
    e.preventDefault();
    if (!form.name || !form.quantity || !form.price) return;

    await addItem({
      name: form.name,
      quantity: Number(form.quantity),
      price: Number(form.price),
    });

    setForm({ name: "", quantity: "", price: "" });
  }

  return (
    <div className="p-6 space-y-8">
      {/* Título */}
      <h1 className="text-3xl font-bold">Inventario</h1>

      {/* Formulario */}
      <Card className="max-w-xl">
        <CardHeader>
          <CardTitle>Agregar producto</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Input
              name="name"
              placeholder="Nombre"
              value={form.name}
              onChange={handleChange}
            />
            <Input
              name="quantity"
              placeholder="Cantidad"
              type="number"
              value={form.quantity}
              onChange={handleChange}
            />
            <Input
              name="price"
              placeholder="Precio"
              type="number"
              value={form.price}
              onChange={handleChange}
            />
            <Button type="submit" className="md:col-span-3">Guardar</Button>
          </form>
        </CardContent>
      </Card>

      {/* Lista / Tabla */}
      <Card>
        <CardHeader>
          <CardTitle>Productos registrados</CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <p>Cargando...</p>
          ) : items.length === 0 ? (
            <p className="text-gray-500">No hay productos.</p>
          ) : (
            <table className="w-full text-left border">
              <thead>
                <tr className="border-b bg-gray-100">
                  <th className="p-3">Producto</th>
                  <th className="p-3">Cantidad</th>
                  <th className="p-3">Precio</th>
                  <th className="p-3"></th>
                </tr>
              </thead>
              <tbody>
                {items.map((item) => (
                  <tr key={item.id} className="border-b hover:bg-gray-50">
                    <td className="p-3">{item.name}</td>
                    <td className="p-3">{item.quantity}</td>
                    <td className="p-3">${item.price}</td>
                    <td className="p-3 text-right">
                      <Button variant="destructive" size="sm" onClick={() => removeItem(item.id)}>
                        <Trash2 size={16} />
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
