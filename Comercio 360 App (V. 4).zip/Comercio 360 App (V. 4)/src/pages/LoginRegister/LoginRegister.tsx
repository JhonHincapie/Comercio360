import { useState } from "react";
import AuthInput from "../../components/AuthInput";
import AuthButton from "../../components/AuthButton";
import { motion, AnimatePresence } from "framer-motion";
import { useAuth } from "../../hooks/useAuth";

const LoginRegister = () => {
  const [isLogin, setIsLogin] = useState(true);

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const { loading, error, login, register } = useAuth();

  const handleSubmit = async (e: any) => {
    e.preventDefault();

    if (isLogin) {
      const ok = await login(email, password);
      if (ok) alert("Login correcto");
    } else {
      const ok = await register(email, password);
      if (ok) alert("Usuario creado con éxito");
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-purple-600 to-pink-500 px-4">
      <div className="bg-white w-full max-w-md rounded-3xl p-8 shadow-2xl">
        
        <AnimatePresence>
          {isLogin ? (
            <motion.div
              key="login"
              initial={{ opacity: 0, x: 80 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -80 }}
              transition={{ duration: 0.4 }}
            >
              <h1 className="text-3xl font-bold text-center text-purple-600 mb-6">
                Bienvenido 👋
              </h1>

              <form onSubmit={handleSubmit}>
                <AuthInput 
                  label="Correo" 
                  type="email" 
                  value={email} 
                  onChange={(e) => setEmail(e.target.value)}
                />

                <AuthInput 
                  label="Contraseña" 
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />

                {error && <p className="text-red-500 text-center mb-2">{error}</p>}

                <AuthButton type="submit" label="Ingresar" loading={loading} />
              </form>

              <p className="text-center mt-4">
                ¿No tienes cuenta?{" "}
                <span 
                  className="text-purple-600 font-semibold cursor-pointer"
                  onClick={() => setIsLogin(false)}
                >
                  Crear cuenta
                </span>
              </p>
            </motion.div>
          ) : (
            <motion.div
              key="register"
              initial={{ opacity: 0, x: -80 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 80 }}
              transition={{ duration: 0.4 }}
            >
              <h1 className="text-3xl font-bold text-center text-pink-600 mb-6">
                Crear cuenta ✨
              </h1>

              <form onSubmit={handleSubmit}>
                <AuthInput 
                  label="Correo" 
                  type="email" 
                  value={email} 
                  onChange={(e) => setEmail(e.target.value)}
                />

                <AuthInput 
                  label="Contraseña" 
                  type="password" 
                  value={password} 
                  onChange={(e) => setPassword(e.target.value)}
                />

                {error && <p className="text-red-500 text-center mb-2">{error}</p>}

                <AuthButton type="submit" label="Registrarme" loading={loading} />
              </form>

              <p className="text-center mt-4">
                ¿Ya tienes cuenta?{" "}
                <span 
                  className="text-pink-600 font-semibold cursor-pointer"
                  onClick={() => setIsLogin(true)}
                >
                  Iniciar sesión
                </span>
              </p>
            </motion.div>
          )}
        </AnimatePresence>

      </div>
    </div>
  );
};

export default LoginRegister;
