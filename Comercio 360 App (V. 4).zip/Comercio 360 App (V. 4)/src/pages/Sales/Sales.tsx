import { useState } from "react";
import { useSales } from "@/hooks/useSales";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Trash2 } from "lucide-react";

export default function Sales() {
  const { sales, loading, add, remove } = useSales();
  const [form, setForm] = useState({
    product: "",
    quantity: "",
    total: "",
  });

  function handleChange(e: any) {
    setForm({ ...form, [e.target.name]: e.target.value });
  }

  async function handleSubmit(e: any) {
    e.preventDefault();
    if (!form.product || !form.quantity || !form.total) return;

    await add({
      product: form.product,
      quantity: Number(form.quantity),
      total: Number(form.total),
      date: new Date().toISOString(),
    });

    setForm({ product: "", quantity: "", total: "" });
  }

  const totalDay = sales.reduce((acc, sale) => acc + sale.total, 0);

  return (
    <div className="p-6 space-y-8">
      <h1 className="text-3xl font-bold">Ventas</h1>

      {/* Card: Totales */}
      <Card className="border-green-500">
        <CardHeader>
          <CardTitle className="text-green-600">Total del día: ${totalDay}</CardTitle>
        </CardHeader>
      </Card>

      {/* Formulario */}
      <Card className="max-w-xl">
        <CardHeader>
          <CardTitle>Registrar venta</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Input 
              name="product"
              placeholder="Producto"
              value={form.product}
              onChange={handleChange}
            />

            <Input 
              name="quantity"
              placeholder="Cantidad"
              type="number"
              value={form.quantity}
              onChange={handleChange}
            />

            <Input 
              name="total"
              placeholder="Total ($)"
              type="number"
              value={form.total}
              onChange={handleChange}
            />

            <Button className="md:col-span-3" type="submit">
              Guardar venta
            </Button>
          </form>
        </CardContent>
      </Card>

      {/* Tabla */}
      <Card>
        <CardHeader>
          <CardTitle>Historial de ventas</CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <p>Cargando...</p>
          ) : sales.length === 0 ? (
            <p className="text-gray-500">Aún no hay ventas registradas.</p>
          ) : (
            <table className="w-full text-left border">
              <thead>
                <tr className="border-b bg-gray-50">
                  <th className="p-3">Producto</th>
                  <th className="p-3">Cantidad</th>
                  <th className="p-3">Total</th>
                  <th className="p-3">Fecha</th>
                  <th className="p-3"></th>
                </tr>
              </thead>
              <tbody>
                {sales.map((sale) => (
                  <tr key={sale.id} className="border-b hover:bg-gray-100">
                    <td className="p-3">{sale.product}</td>
                    <td className="p-3">{sale.quantity}</td>
                    <td className="p-3">${sale.total}</td>
                    <td className="p-3">{new Date(sale.date).toLocaleString()}</td>
                    <td className="p-3 text-right">
                      <Button variant="destructive" size="sm" onClick={() => remove(sale.id)}>
                        <Trash2 size={16} />
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
