import { useState } from "react";
import { useExpenses } from "@/hooks/useExpenses";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { Trash2 } from "lucide-react";

export default function Purchases() {
  const { expenses, loading, add, remove } = useExpenses();
  const [form, setForm] = useState({
    type: "compra",
    description: "",
    amount: "",
  });

  function handleChange(e: any) {
    setForm({ ...form, [e.target.name]: e.target.value });
  }

  async function handleSubmit(e: any) {
    e.preventDefault();
    if (!form.description || !form.amount) return;

    await add({
      type: form.type,
      description: form.description,
      amount: Number(form.amount),
      date: new Date().toISOString(),
    });

    setForm({ type: "compra", description: "", amount: "" });
  }

  const totalCompras = expenses
    .filter((e) => e.type === "compra")
    .reduce((acc, e) => acc + e.amount, 0);

  const totalGastos = expenses
    .filter((e) => e.type === "gasto")
    .reduce((acc, e) => acc + e.amount, 0);

  return (
    <div className="p-6 space-y-8">
      <h1 className="text-3xl font-bold">Compras y Gastos</h1>

      {/* Totales */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="border-blue-500">
          <CardHeader>
            <CardTitle className="text-blue-600">Total Compras: ${totalCompras}</CardTitle>
          </CardHeader>
        </Card>

        <Card className="border-red-500">
          <CardHeader>
            <CardTitle className="text-red-600">Total Gastos: ${totalGastos}</CardTitle>
          </CardHeader>
        </Card>
      </div>

      {/* Formulario */}
      <Card className="max-w-xl">
        <CardHeader>
          <CardTitle>Registrar compra / gasto</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="grid gap-4">

            <Select
              value={form.type}
              onValueChange={(val) => setForm({ ...form, type: val })}
            >
              <SelectTrigger>
                <SelectValue placeholder="Tipo" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="compra">Compra</SelectItem>
                <SelectItem value="gasto">Gasto</SelectItem>
              </SelectContent>
            </Select>

            <Input
              name="description"
              placeholder="Descripción"
              value={form.description}
              onChange={handleChange}
            />

            <Input
              name="amount"
              type="number"
              placeholder="Valor ($)"
              value={form.amount}
              onChange={handleChange}
            />

            <Button type="submit">Guardar</Button>
          </form>
        </CardContent>
      </Card>

      {/* Tabla */}
      <Card>
        <CardHeader>
          <CardTitle>Historial</CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <p>Cargando...</p>
          ) : expenses.length === 0 ? (
            <p className="text-gray-500">No se han registrado compras o gastos.</p>
          ) : (
            <table className="w-full text-left border">
              <thead>
                <tr className="bg-gray-50 border-b">
                  <th className="p-3">Tipo</th>
                  <th className="p-3">Descripción</th>
                  <th className="p-3">Valor</th>
                  <th className="p-3">Fecha</th>
                  <th className="p-3"></th>
                </tr>
              </thead>
              <tbody>
                {expenses.map((e) => (
                  <tr key={e.id} className="border-b hover:bg-gray-100">
                    <td className="p-3 capitalize">{e.type}</td>
                    <td className="p-3">{e.description}</td>
                    <td className="p-3">${e.amount}</td>
                    <td className="p-3">{new Date(e.date).toLocaleString()}</td>
                    <td className="p-3 text-right">
                      <Button variant="destructive" size="sm" onClick={() => remove(e.id)}>
                        <Trash2 size={16} />
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
