import { useState } from "react";
import { motion } from "framer-motion";
import { Link, useLocation } from "react-router-dom";
import { Home, Package, ShoppingCart, BarChart2, Settings } from "lucide-react";

const menuItems = [
  { label: "Dashboard", icon: <Home size={20} />, path: "/dashboard" },
  { label: "Inventario", icon: <Package size={20} />, path: "/inventory" },
  { label: "Compras / Gastos", icon: <ShoppingCart size={20} />, path: "/expenses" },
  { label: "Ventas", icon: <BarChart2 size={20} />, path: "/sales" },
  { label: "Configuración", icon: <Settings size={20} />, path: "/settings" },
];

export const Sidebar = () => {
  const [open, setOpen] = useState(true);
  const { pathname } = useLocation();

  return (
    <motion.div 
      animate={{ width: open ? 240 : 70 }}
      className="bg-purple-700 text-white min-h-screen py-6 px-3 flex flex-col shadow-xl transition-all"
    >
      <button onClick={() => setOpen(!open)} className="mb-6 text-left">
        <motion.h2 
          animate={{ opacity: open ? 1 : 0 }} 
          className="text-2xl font-bold"
        >
          C-360
        </motion.h2>
      </button>

      <nav className="flex-1 flex flex-col gap-2">
        {menuItems.map((item, index) => (
          <Link 
            key={index}
            to={item.path}
            className={`flex items-center gap-3 p-3 rounded-xl transition-all 
              ${pathname === item.path ? "bg-purple-500 shadow-md" : "hover:bg-purple-600"}`}
          >
            {item.icon}
            {open && <span className="font-medium">{item.label}</span>}
          </Link>
        ))}
      </nav>
    </motion.div>
  );
};
