import { useNavigate } from "react-router-dom";
import { auth } from "../services/firebase";

export const Topbar = () => {
  const navigate = useNavigate();

  const logout = async () => {
    await auth.signOut();
    navigate("/");
  };

  return (
    <div className="w-full h-16 bg-white shadow flex items-center justify-between px-6">
      <h1 className="text-xl font-semibold text-gray-700">Comercio 360</h1>

      <button 
        onClick={logout}
        className="bg-purple-600 text-white px-4 py-2 rounded-xl hover:bg-purple-700"
      >
        Cerrar sesión
      </button>
    </div>
  );
};
