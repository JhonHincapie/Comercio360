// src/layout/AppLayout.tsx
import { useState } from "react";
import { NavLink, Outlet } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";
import {
  LuHome,
  LuPackage,
  LuTrendingUp,
  LuShoppingCart,
  LuWallet,
  LuLogOut,
  LuMenu,
} from "react-icons/lu";

export default function AppLayout() {
  const { logout } = useAuth();
  const [open, setOpen] = useState(true);

  const menuItems = [
    { name: "Dashboard", icon: <LuHome />, path: "/dashboard" },
    { name: "Inventario", icon: <LuPackage />, path: "/inventario" },
    { name: "Ventas", icon: <LuTrendingUp />, path: "/ventas" },
    { name: "Compras", icon: <LuShoppingCart />, path: "/compras" },
    { name: "Gastos", icon: <LuWallet />, path: "/gastos" },
  ];

  return (
    <div className="flex h-screen bg-gray-100">

      {/* SIDEBAR */}
      <aside
        className={`bg-white border-r shadow-md transition-all duration-300 relative
          ${open ? "w-64" : "w-20"}`
        }
      >
        <div className="p-4 flex items-center justify-between">
          <h1
            className={`text-xl font-bold text-purple-600 transition-opacity duration-200
              ${open ? "opacity-100" : "opacity-0 pointer-events-none"}
            `}
          >
            Comercio 360
          </h1>

          {/* Botón menú */}
          <button
            onClick={() => setOpen(!open)}
            className="p-2 rounded hover:bg-gray-200"
          >
            <LuMenu />
          </button>
        </div>

        {/* Menú */}
        <nav className="mt-6">
          {menuItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) =>
                `flex items-center gap-4 px-4 py-3 cursor-pointer transition-all
                ${
                  isActive
                    ? "bg-purple-100 text-purple-600 font-semibold"
                    : "text-gray-700 hover:bg-gray-100"
                }`
              }
            >
              <span className="text-xl">{item.icon}</span>
              <span
                className={`transition-all duration-200
                  ${open ? "opacity-100" : "opacity-0 pointer-events-none"}
              `}
              >
                {item.name}
              </span>
            </NavLink>
          ))}
        </nav>

        {/* Logout */}
        <button
          onClick={logout}
          className="absolute bottom-6 left-4 flex items-center gap-4 text-red-500 hover:text-red-600"
        >
          <LuLogOut className="text-xl" />
          <span className={`${open ? "block" : "hidden"}`}>Cerrar sesión</span>
        </button>
      </aside>

      {/* CONTENIDO PRINCIPAL */}
      <main className="flex-1 flex flex-col">
        {/* TOPBAR */}
        <header className="h-16 bg-white border-b shadow-sm flex items-center px-6">
          <h2 className="text-lg font-semibold text-gray-800">
            Bienvenido 👋
          </h2>
        </header>

        {/* CONTENIDO DINÁMICO */}
        <div className="p-6 overflow-auto h-[calc(100vh-4rem)]">
          <Outlet />
        </div>
      </main>
    </div>
  );
}
