import { useEffect, useState } from "react";
import { addSale, deleteSale, getSales } from "@/services/salesService";

export function useSales() {
  const [sales, setSales] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  async function load() {
    setLoading(true);
    const data = await getSales();
    setSales(data);
    setLoading(false);
  }

  async function add(data: { product: string; quantity: number; total: number; date: string }) {
    await addSale(data);
    await load();
  }

  async function remove(id: string) {
    await deleteSale(id);
    await load();
  }

  useEffect(() => {
    load();
  }, []);

  return { sales, loading, add, remove };
}
