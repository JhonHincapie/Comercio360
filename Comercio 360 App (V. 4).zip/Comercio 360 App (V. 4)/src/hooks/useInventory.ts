import { useEffect, useState } from "react";
import { addInventoryItem, deleteInventoryItem, getInventory } from "@/services/inventoryService";

export function useInventory() {
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  async function loadItems() {
    setLoading(true);
    const data = await getInventory();
    setItems(data);
    setLoading(false);
  }

  async function addItem(item: { name: string; quantity: number; price: number }) {
    await addInventoryItem(item);
    await loadItems();
  }

  async function removeItem(id: string) {
    await deleteInventoryItem(id);
    await loadItems();
  }

  useEffect(() => {
    loadItems();
  }, []);

  return {
    items,
    loading,
    addItem,
    removeItem,
  };
}
