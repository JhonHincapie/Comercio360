import { useEffect, useState } from "react";
import { addExpense, deleteExpense, getExpenses } from "@/services/expensesService";

export function useExpenses() {
  const [expenses, setExpenses] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  async function load() {
    setLoading(true);
    const data = await getExpenses();
    setExpenses(data);
    setLoading(false);
  }

  async function add(data: { type: string; description: string; amount: number; date: string }) {
    await addExpense(data);
    await load();
  }

  async function remove(id: string) {
    await deleteExpense(id);
    await load();
  }

  useEffect(() => {
    load();
  }, []);

  return { expenses, loading, add, remove };
}
